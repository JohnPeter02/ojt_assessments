<?php

namespace App\Http\Controllers;

use App\Models\Inventory;
use Database\Factories\InventoryFactory;
use Illuminate\Http\Request;

class InventoryController extends Controller
{
    /** index page inventory list */
    public function inventory()
    {
        $inventoryList = Inventory::all();
        return view('inventory.inventory', compact('inventoryList'));
    }

    /** index page inventory grid */
    public function inventoryGrid()
    {
        $inventoryList = Inventory::all();
        return view('inventory.inventory-grid', compact('inventoryList'));
    }

    /** inventory add page */
    public function inventoryAdd()
    {
        return view('inventory.add-inventory');
    }

    /** inventory save record */
    public function inventorySave(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'email' => 'required|email',
            'address' => 'required',
            'phone_number' => 'required',
            'upload' => 'required|image',
        ]);

        DB::beginTransaction();
        try {

            $upload_file = rand() . '.' . $request->upload->extension();
            $request->upload->move(storage_path('app/public/inventory-photos/'), $upload_file);
            if (!empty($request->upload)) {
                $inventory = new Inventory();
                $inventory->name = $request->name;
                $inventory->upload = $upload_file;
                $inventory->save();

                Toastr::success('Inventory has been add successfully :)', 'Success');
                DB::commit();
            }

            return redirect()->back();

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Failed to add new inventory.', 'Error');
            return redirect()->back();
        }
    }

    /** view for edit inventory */
    public function inventoryEdit($id)
    {
        $inventoryEdit = Inventory::where('id', $id)->first();
        return view('inventory.edit-inventory', compact('inventoryEdit'));
    }

    /** update record */
    public function inventoryUpdate(Request $request)
    {
        DB::beginTransaction();
        try {

            if (!empty($request->upload)) {
                unlink(storage_path('app/public/inventory-photos/' . $request->image_hidden));
                $upload_file = rand() . '.' . $request->upload->extension();
                $request->upload->move(storage_path('app/public/inventory-photos/'), $upload_file);
            } else {
                $upload_file = $request->image_hidden;
            }

            $updateRecord = [
                'upload' => $upload_file,
            ];
            Inventory::where('id', $request->id)->update($updateRecord);

            Toastr::success('Inventory has been updated successfully.', 'Success');
            DB::commit();
            return redirect()->back();

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Failed to update inventory.', 'Error');
            return redirect()->back();
        }
    }

    /** inventory delete */
    public function inventoryDelete(Request $request)
    {
        DB::beginTransaction();
        try {

            if (!empty($request->id)) {
                Inventory::destroy($request->id);
                unlink(storage_path('app/public/inventory-photos/' . $request->avatar));
                DB::commit();
                Toastr::success('Inventory deleted successfully.', 'Success');
                return redirect()->back();
            }

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Inventory failed to delete.', 'Error');
            return redirect()->back();
        }
    }


}
