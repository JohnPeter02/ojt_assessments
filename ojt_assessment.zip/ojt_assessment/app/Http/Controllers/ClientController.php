<?php

namespace App\Http\Controllers;

use DB;
use App\Models\Client;
use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;

class ClientController extends Controller
{
    /** index page client list */
    public function client()
    {
        $clientList = Client::all();
        return view('client.client', compact('clientList'));
    }

    /** index page client grid */
    public function clientGrid()
    {
        $clientList = Client::all();
        return view('client.client-grid', compact('clientList'));
    }

    /** client add page */
    public function clientAdd()
    {
        return view('client.add-client');
    }

    /** client save record */
    public function clientSave(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'email' => 'required|email',
            'address' => 'required',
            'phone_number' => 'required',
            'upload' => 'required|image',
        ]);

        DB::beginTransaction();
        try {

            $upload_file = rand() . '.' . $request->upload->extension();
            $request->upload->move(storage_path('app/public/client-photos/'), $upload_file);
            if (!empty($request->upload)) {
                $client = new Client;
                $client->first_name = $request->first_name;
                $client->last_name = $request->last_name;
                $client->email = $request->email;
                $client->address = $request->address;
                $client->phone_number = $request->phone_number;
                $client->upload = $upload_file;
                $client->save();

                Toastr::success('Client has been add successfully :)', 'Success');
                DB::commit();
            }

            return redirect()->back();

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Failed to add new client.', 'Error');
            return redirect()->back();
        }
    }

    /** view for edit client */
    public function clientEdit($id)
    {
        $clientEdit = Client::where('id', $id)->first();
        return view('client.edit-client', compact('clientEdit'));
    }

    /** update record */
    public function clientUpdate(Request $request)
    {
        DB::beginTransaction();
        try {

            if (!empty($request->upload)) {
                unlink(storage_path('app/public/client-photos/' . $request->image_hidden));
                $upload_file = rand() . '.' . $request->upload->extension();
                $request->upload->move(storage_path('app/public/client-photos/'), $upload_file);
            } else {
                $upload_file = $request->image_hidden;
            }

            $updateRecord = [
                'upload' => $upload_file,
            ];
            Client::where('id', $request->id)->update($updateRecord);

            Toastr::success('Client has been updated successfully.', 'Success');
            DB::commit();
            return redirect()->back();

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Failed to update client.', 'Error');
            return redirect()->back();
        }
    }

    /** client delete */
    public function clientDelete(Request $request)
    {
        DB::beginTransaction();
        try {

            if (!empty($request->id)) {
                Client::destroy($request->id);
                unlink(storage_path('app/public/client-photos/' . $request->avatar));
                DB::commit();
                Toastr::success('Client deleted successfully.', 'Success');
                return redirect()->back();
            }

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Client failed to delete.', 'Error');
            return redirect()->back();
        }
    }

    /** client profile page */
    public function clientProfile($id)
    {
        $clientProfile = Client::where('id', $id)->first();
        return view('client.client-profile', compact('clientProfile'));
    }
}
