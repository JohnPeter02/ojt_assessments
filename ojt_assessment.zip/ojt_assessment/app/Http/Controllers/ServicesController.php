<?php

namespace App\Http\Controllers;

use DB;

use Brian2694\Toastr\Facades\Toastr;
use App\Models\Services;
use App\Models\Inventory;
use Illuminate\Http\Request;

class ServicesController extends Controller
{
    /** index page services list */
    public function services()
    {
        $servicesList = Services::all();
        return view('services.services', compact('servicesList'));
    }

    public function inventoryGrid($id)
    {
        // Fetch the inventory for the given service ID
        $service = Services::findOrFail($id);
        $inventoryList = Inventory::where('service_id', $id)->get();

        return view('services/inventory-grid', compact('service', 'inventoryList'));
    }


    /** index page services grid */
    public function servicesGrid()
    {
        $servicesList = Services::all();
        return view('services.services-grid', compact('servicesList'));
    }

    /** services add page */
    public function servicesAdd()
    {
        return view('services.add-services');
    }

    /** inventory add page */
    public function inventoryAdd()
    {
        return view('inventory/add-inventory');
    }

    /** services save record */
    public function servicesSave(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'price_per_hour' => 'required|numeric',

            'upload' => 'required|image',
        ]);

        DB::beginTransaction();
        try {

            $upload_file = rand() . '.' . $request->upload->extension();
            $request->upload->move(storage_path('app/public/services-photos/'), $upload_file);
            if (!empty($request->upload)) {
                $services = new Services;
                $services->name = $request->name;
                $services->price_per_hour = $request->price_per_hour;

                $services->upload = $upload_file;
                $services->save();

                Toastr::success('Services has been add successfully :)', 'Success');
                DB::commit();
            }

            return redirect()->back();

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Failed to add new services.', 'Error');
            return redirect()->back();
        }
    }

    /** view for edit services */
    public function servicesEdit($id)
    {
        $servicesEdit = Services::where('id', $id)->first();
        return view('services.edit-services', compact('servicesEdit'));
    }

    /** update record */
    public function servicesUpdate(Request $request)
    {
        DB::beginTransaction();
        try {

            if (!empty($request->upload)) {
                unlink(storage_path('app/public/services-photos/' . $request->image_hidden));
                $upload_file = rand() . '.' . $request->upload->extension();
                $request->upload->move(storage_path('app/public/services-photos/'), $upload_file);
            } else {
                $upload_file = $request->image_hidden;
            }

            $updateRecord = [
                'upload' => $upload_file,
            ];
            Services::where('id', $request->id)->update($updateRecord);

            Toastr::success('Services has been updated successfully.', 'Success');
            DB::commit();
            return redirect()->back();

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Failed to update services.', 'Error');
            return redirect()->back();
        }
    }

    /** services delete */
    public function servicesDelete(Request $request)
    {
        DB::beginTransaction();
        try {

            if (!empty($request->id)) {
                Services::destroy($request->id);
                unlink(storage_path('app/public/services-photos/' . $request->avatar));
                DB::commit();
                Toastr::success('Services deleted successfully.', 'Success');
                return redirect()->back();
            }

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Services failed to delete.', 'Error');
            return redirect()->back();
        }
    }
}
