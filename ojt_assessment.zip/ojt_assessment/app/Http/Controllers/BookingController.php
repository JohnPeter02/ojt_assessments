<?php

namespace App\Http\Controllers;

use DB;
use App\Models\Booking;
use App\Models\BookingService;
use App\Models\Client;
use App\Models\Service;
use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Storage;

class BookingController extends Controller
{
    /** index page booking list */
    public function booking()
    {
        $bookingList = Booking::with('client')->get(); // Eager load client data
        return view('booking.booking', compact('bookingList'));
    }

    /** index page booking grid */
    public function bookingGrid()
    {
        $bookingList = Booking::all();
        return view('booking.booking-grid', compact('bookingList'));
    }

    /** booking add page */
    public function bookingAdd()
    {

        $clientName = Client::all();
        $serviceName = Service::all();

        return view('booking.add-booking', compact('clientName', 'serviceName'));
    }

    /** Booking Save Record */
    public function bookingSave(Request $request)
    {
        $request->validate([
            'client' => 'required|exists:clients,id',
            'date' => [
                'required',
                'date',
                function ($attribute, $value, $fail) {
                    if (Booking::where('date', $value)->exists()) {
                        $fail('The selected date already has a booking. Please choose another date.');
                    }
                },
            ],
            'service' => 'required|array',
            'service.*' => 'exists:services,id',
            'duration' => 'required|array',
            'duration.*' => 'integer|min:1',
        ]);

        try {
            // Start transaction in case of failure
            DB::beginTransaction();

            // Create booking
            $booking = Booking::create([
                'client_id' => $request->client,
                'date' => $request->date,
                'other_reason' => $request->other_reason,
                'total_amount' => 0, // Will update after adding services
            ]);

            $totalAmount = 0;

            // Attach services
            foreach ($request->service as $index => $serviceId) {
                $duration = $request->duration[$index];

                // Ensure service exists and has a valid price
                $service = Service::findOrFail($serviceId);
                $pricePerHour = $service->price_per_hour ?? 0;
                $totalPrice = $pricePerHour * $duration;

                // Save service to booking
                BookingService::create([
                    'booking_id' => $booking->id,
                    'service_id' => $serviceId,
                    'duration' => $duration,
                    'price_per_hour' => $pricePerHour,
                    'total_price' => $totalPrice,
                ]);

                $totalAmount += $totalPrice;
            }

            // Update total amount in booking
            $booking->update(['total_amount' => $totalAmount]);

            // Commit transaction if everything is successful
            DB::commit();

            Toastr::success('Booking has been successfully saved.', 'Success');
            return redirect()->route('booking/list');
        } catch (\Exception $e) {
            // Rollback transaction if something goes wrong
            DB::rollBack();

            // Log the error for debugging
            \Log::error('Booking Save Error: ' . $e->getMessage());

            Toastr::error('Failed to save booking.', 'Error');
            return redirect()->back()->withInput();
        }
    }



    /** view for edit booking */
    public function bookingEdit($id)
    {
        $bookingEdit = Booking::findOrFail($id);
        $clientName = Client::all();
        $serviceName = Service::all();
        return view('booking.edit-booking', compact('bookingEdit', 'clientName', 'serviceName'));
    }

    /** update record */
    public function bookingUpdate(Request $request)
    {
        $request->validate([
            'client_id' => 'required|exists:clients,id',
            'date' => 'required|date',
            'service_id' => 'required|exists:services,id',
            'duration' => 'required|integer|min:1',
        ]);

        DB::beginTransaction();
        try {
            $booking = Booking::findOrFail($request->id);

            // Update record
            $booking->update([
                'client_id' => $request->client_id,
                'date' => $request->date,
                'service_id' => $request->service_id,
                'duration' => $request->duration,
            ]);

            DB::commit();
            Toastr::success('Booking has been updated successfully.', 'Success');
            return redirect()->route('booking/list');

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Failed to update booking.', 'Error');
            return redirect()->back()->withInput();
        }
    }

    /** booking delete */
    public function bookingDelete(Request $request)
    {
        DB::beginTransaction();
        try {

            if (!empty($request->id)) {
                Booking::destroy($request->id);
                unlink(storage_path('app/public/booking-photos/' . $request->avatar));
                DB::commit();
                Toastr::success('Booking deleted successfully.', 'Success');
                return redirect()->back();
            }

        } catch (\Exception $e) {
            DB::rollback();
            Toastr::error('Booking failed to delete.', 'Error');
            return redirect()->back();
        }
    }

    /** booking profile page */
    public function bookingProfile($id)
    {
        $bookingProfile = Booking::where('id', $id)->first();
        return view('booking.booking-profile', compact('bookingProfile'));
    }
}
