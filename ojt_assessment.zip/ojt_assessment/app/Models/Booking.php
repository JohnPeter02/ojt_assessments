<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'client_id',
        'date',
        'other_reason',
        'total_amount',
    ];

    // Relationship: A booking belongs to a client
    public function client()
    {
        return $this->belongsTo(Client::class, 'client_id');
    }

    public function services()
    {
        return $this->belongsToMany(Service::class, 'booking_services'); // Adjust table name if needed
    }
}
